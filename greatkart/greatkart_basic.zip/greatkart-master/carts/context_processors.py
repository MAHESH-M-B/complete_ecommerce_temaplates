def cart(request):
    return {"cart": request.cart}
