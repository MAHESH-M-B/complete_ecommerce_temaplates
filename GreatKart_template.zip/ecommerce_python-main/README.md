ecommerce_python

Run the project from Docker container

    Navigate to the project root directory
    Copy paste this command docker-compose build and hit enter
    Copy paste this command docker-compose up and hit enter
    Open your browser and go to 127.0.0.1:8000 and not to 0.0.0.0:8000
